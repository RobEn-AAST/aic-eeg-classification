from .EEGDataset import EEGDataset
from .utils  import split_and_get_loaders, evaluate_model