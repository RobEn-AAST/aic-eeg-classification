from .competition_dataset import EEGDataset, decode_label, position_decode
from .trainer import Trainer