from .competition_dataset_windowed import EEGDataset, decode_label, position_decode
from .trainer import Trainer