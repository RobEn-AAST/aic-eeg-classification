from .competition_dataset import EEGDataset
from .trainer import Trainer